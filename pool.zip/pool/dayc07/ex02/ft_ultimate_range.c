/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: youssama <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/08/23 11:27:52 by youssama          #+#    #+#             */
/*   Updated: 2021/08/23 11:34:36 by youssama         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
int	ft_ultimate_range(int **range, int min, int max)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	if (min >= max)
	{
		(*range) = NULL;
		return (0);
	}
	i = max - min;
	(*range) = (int *)malloc(sizeof(int) * i);
	if (!(*range))
	{
		*range = NULL;
		return (-1);
	}
	while (j < i)
	{
		(*range)[j] = min;
		min++;
		j++;
	}
	(*range)[j] = '\0';
	return (j);
}
