/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: youssama <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/08/23 11:35:17 by youssama          #+#    #+#             */
/*   Updated: 2021/08/23 11:41:59 by youssama         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
int	strle(char *s)
{
	int	i;

	i = 0;
	while (s[i] != '\0')
	{
		i++;
	}
	return (i);
}

void	ft_strcpy(char *de, char *sr, int *k)
{
	int	i;

	i = 0;
	while (sr[i])
	{
		de[i] = sr[i];
		(*k)++;
		i++;
	}
	de[i] = '\0';
}

char	*ft_strjoin(int size, char **strs, char *sep)
{
	int		i;
	char	*str;
	int		length;
	int		seple;
	int		k;

	i = 0;
	k = 0;
	length = 0;
	seple = 0;
	seple = strle(sep);
	if (size == 0)
	{
str = (char *)malloc(1);
str[0] = 0;
return tab;
	}
	length = size * seple;
	str = (char *)malloc(sizeof(char) * length);
	if (!str)
		return ((char *)0);
	while (strs[i])
	{
		ft_strcpy(str + k, strs[i], &k);
		if (i + 1 != size)
		{
			ft_strcpy(str + k, sep, &k);
		}
		i++;
	}
	return (str);
}
