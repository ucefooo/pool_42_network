/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: youssama <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/08/23 11:21:35 by youssama          #+#    #+#             */
/*   Updated: 2021/08/24 19:10:24 by youssama         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
int	*ft_range(int min, int max)
{
	int	i;
	int	j;
	int	*t;

	i = 0;
	j = 0;
	if (min >= max)
	{
		return (NULL);
	}
	i = max - min;
	t = (int *)malloc(sizeof(int) * i);
	if (!t)
		return (0);
	while (j < i)
	{
		t[j] = min;
		min++;
		j++;
	}
	return (t);
}
