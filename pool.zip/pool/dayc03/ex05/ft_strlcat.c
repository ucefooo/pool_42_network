/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: youssama <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/08/15 10:44:57 by youssama          #+#    #+#             */
/*   Updated: 2021/08/15 11:55:52 by youssama         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
int	ft_strlen(char *d)
{
	int	i;

	i = 0;
	while (d[i])
	{
		i++;
	}
	return (i);
}

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	unsigned int	i;
	int				a;
	int				m;
	unsigned int	j;

	i = ft_strlen(dest);
	a = 0;
	m = ft_strlen(src);
	j = i;
	if (i >= size)
	{
		return (size + m);
	}
	while (src[a] && j < size - 1)
	{
		dest[a + i] = src[a];
		a++;
		j++;
	}
	dest[a + i] = '\0';
	return (i + m);
}
