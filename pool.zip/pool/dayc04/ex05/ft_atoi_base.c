/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi_base.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: youssama <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/08/18 11:02:10 by youssama          #+#    #+#             */
/*   Updated: 2021/08/18 11:09:17 by youssama         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	test_base(char *base)
{
	int	i;
	int	j;
	int	k;

	j = 0;
	k = 0;
	i = 0;
	while (base[i] != '\0')
	{
		if (base[i] == ' ' || base[i] == '\t' || base[i] == '-'
			|| base[i] == '+' || base[i] == '\n' || base[i] == '\v'
			|| base[i] == '\f' || base[i] == '\r')
		{
			return (0);
		}
		j = i + 1;
		while (base[j] != '\0')
		{
			if (base[i] == base[j])
				return (0);
			j++;
		}
		i++;
	}
	return (i);
}

int	test_arg(char *str, int *i)
{
	int	m;
	int	n;

	m = 1;
	n = 0;
	while (str[*i] == ' ' || str[*i] == '\t'
		|| str[*i] == '\n' || str[*i] == '\v'
		|| str[*i] == '\f' || str[*i] == '\r')
	{
		(*i)++;
	}
	while (str[*i] == '-' || str[*i] == '+')
	{
		if (str[*i] == '-')
		{
			m *= -1;
		}
		(*i)++;
	}
	return (m);
}

int	test_c(char c, char *b)
{
	int	i;

	i = 0;
	while (b[i] != '\0')
	{
		if (c == b[i])
		{
			return (i);
		}
		i++;
	}
	return (-1);
}

int	ft_atoi_base(char *str, char *base)
{
	int	i;
	int	b;
	int	s;
	int	n;
	int	t;

	i = 0;
	t = 0;
	b = 0;
	n = 0;
	s = 0;
	b = test_base(base);
	s = test_arg(str, &i);
	if (b >= 2)
	{
		t = test_c(str[i], base);
		while (t != -1)
		{
			n = n * b + t;
			i++;
			t = test_c(str[i], base);
		}
		return (n * s);
	}
	return (0);
}
