/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_params.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: youssama <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/08/19 19:47:53 by youssama          #+#    #+#             */
/*   Updated: 2021/08/19 19:53:50 by youssama         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
void	chart(char c)
{
	write(1, &c, 1);
}

int	ft_strcmp(char *s1, char *s2)
{
	int	i;

	i = 0;
	while (s1[i] && s2[i] && s1[i] == s2[i])
	{
		i++;
	}
	return (s1[i] - s2[i]);
}

void	sort(char **t, int size)
{
	int		i;
	int		j;
	char	*p;

	i = 1;
	j = 0;
	while (i < size)
	{
		j = i + 1;
		while (j < size)
		{
			if (ft_strcmp(t[i], t[j]) > 0)
			{
				p = t[i];
				t[i] = t[j];
				t[j] = p;
			}
			j++;
		}
		i++;
	}
}

int	main(int c, char **v)
{
	int	i;
	int	j;

	i = 1;
	j = 0;
	if (c > 1)
	{
		sort(v, c);
		while (i < c)
		{
			j = 0;
			while (v[i][j] != '\0')
			{
				chart(v[i][j]);
				j++;
			}
			chart('\n');
			i++;
		}
	}
	return (0);
}
