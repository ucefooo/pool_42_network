/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_params.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: youssama <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/08/19 19:40:14 by youssama          #+#    #+#             */
/*   Updated: 2021/08/19 19:43:20 by youssama         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
void	chart(char c)
{
	write(1, &c, 1);
}

int	main(int c, char **v)
{
	int	i;
	int	j;

	i = 1;
	j = 0;
	while (i < c)
	{
		j = 0;
		while (v[i][j] != '\0')
		{
			chart(v[i][j]);
			j++;
		}
		chart('\n');
		i++;
	}
	return (0);
}
