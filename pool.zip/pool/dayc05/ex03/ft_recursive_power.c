/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: youssama <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/08/19 19:15:57 by youssama          #+#    #+#             */
/*   Updated: 2021/08/19 19:18:05 by youssama         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_recursive_power(int nb, int power)
{
	int	n;
	int	f;

	n = 1;
	if (power < 0)
	{
		return (0);
	}
	if ((power == 0 && nb == 0) || power == 0)
	{
		return (1);
	}
	if (power == 1)
	{
		return (nb);
	}
	if (power > 1)
	{
		f = nb;
		f = f * ft_recursive_power(nb, power - 1);
		return (f);
	}
	return (0);
}
