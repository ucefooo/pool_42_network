/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: youssama <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/08/07 14:55:43 by youssama          #+#    #+#             */
/*   Updated: 2021/08/08 15:05:10 by youssama         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	testp(long	n)
{
	int	b;

	if (n >= 0 && n < 10)
	{
		ft_putchar(n + 48);
	}
	if (n >= 10)
	{
		b = n % 10;
		n = n / 10;
		testp(n);
		ft_putchar(b + 48);
	}
}

void	testn(long n)
{
	int	b;

	if (n < 0 && n > (-10))
	{
		ft_putchar ('-');
		n = n * (-1);
		ft_putchar(n + 48);
	}
	if (n <= (-10))
	{
		ft_putchar('-');
		n = n * -1;
		b = n % 10;
		n = n / 10;
		testp(n);
		ft_putchar(b + 48);
	}
}

void	ft_putnbr(int nb)
{
	long	n;

	n = nb;
	testn(n);
	testp(n);
}
