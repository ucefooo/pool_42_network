/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: youssama <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/08/05 19:21:48 by youssama          #+#    #+#             */
/*   Updated: 2021/08/06 11:09:07 by youssama         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<unistd.h>
void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	comb( int a, int b )
{
	ft_putchar(a / 10 + ('0'));
	ft_putchar(a % 10 + ('0'));
	ft_putchar(' ');
	ft_putchar(b / 10 + ('0'));
	ft_putchar(b % 10 + ('0'));
	if (a != 98 )
	{
		ft_putchar(',');
		ft_putchar(' ');
	}
}

void	ft_print_comb2(void)
{	
	int	i;
	int	j;

	i = 0;
	while (i <= 98)
	{
		j = i + 1;
		while (j <= 99)
		{
			comb(i, j);
			j++;
		}
		i++;
	}
}
