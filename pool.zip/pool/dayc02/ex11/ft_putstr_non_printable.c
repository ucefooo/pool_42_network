/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr_non_printable.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: youssama <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/08/10 10:02:57 by youssama          #+#    #+#             */
/*   Updated: 2021/08/11 19:30:23 by youssama         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
void	chart(char r)
{
	write(1, &r, 1);
}

void	ft_putstr_non_printable(char *str)
{
	int				i;
	unsigned char	c;

	i = 0;
	while (str[i])
	{
		c = str[i];
		if (str[i] >= 32 && str[i] <= 126)
		{
			chart(str[i]);
		}
		else
		{
			chart('\\');
			chart("0123456789abcdef"[c / 16]);
			chart("0123456789abcdef"[c % 16]);
		}
		i++;
	}
}
